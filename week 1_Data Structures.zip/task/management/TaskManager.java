package task.management;

public class TaskManager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TaskList taskList = new TaskList();

        
        taskList.addTask(new Task("T001", "Fix login bug", "Pending"));
        taskList.addTask(new Task("T002", "Deploy build", "Completed"));
        taskList.addTask(new Task("T003", "Write unit tests", "In Progress"));

        System.out.println("\n=== All Tasks ===");
        taskList.displayTasks();

        System.out.println("\n=== Search Task: T002 ===");
        Task found = taskList.searchTask("T002");
        System.out.println(found != null ? "Found: " + found : "Task not found.");

        System.out.println("\n=== Delete Task: T001 ===");
        boolean deleted = taskList.deleteTask("T001");
        System.out.println(deleted ? "Deleted successfully." : "Delete failed.");

        System.out.println("\n=== Tasks After Deletion ===");
        taskList.displayTasks();
    }

	}


