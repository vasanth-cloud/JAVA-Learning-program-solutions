package sorting.orders;

public class SortTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Order[] orders = {
	            new Order("O001", "Alice", 4500),
	            new Order("O002", "Bob", 1200),
	            new Order("O003", "Charlie", 8900),
	            new Order("O004", "David", 3200),
	            new Order("O005", "Eva", 6700)
	        };

	        System.out.println("=== Original Orders ===");
	        printOrders(orders);

	        // Bubble Sort
	        Order[] bubbleSorted = orders.clone();
	        BubbleSort.sort(bubbleSorted);
	        System.out.println("\n=== Orders Sorted by Bubble Sort (Total Price) ===");
	        printOrders(bubbleSorted);

	        // Quick Sort
	        Order[] quickSorted = orders.clone();
	        QuickSort.sort(quickSorted, 0, quickSorted.length - 1);
	        System.out.println("\n=== Orders Sorted by Quick Sort (Total Price) ===");
	        printOrders(quickSorted);
	    }

	    private static void printOrders(Order[] orders) {
	        for (Order order : orders) {
	            System.out.println(order);
	        }
	    }

	}


