package employee.management;

public class EmployeeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EmployeeManager manager = new EmployeeManager(5);

        
        manager.addEmployee(new Employee("E001", "Alice", "Manager", 75000));
        manager.addEmployee(new Employee("E002", "Bob", "Developer", 60000));
        manager.addEmployee(new Employee("E003", "Charlie", "HR", 50000));

        System.out.println("\n=== Employee List ===");
        manager.listEmployees();

        
        System.out.println("\n=== Search for E002 ===");
        Employee result = manager.searchEmployee("E002");
        if (result != null) {
            System.out.println("Found: " + result);
        } else {
            System.out.println("Employee not found.");
        }

        
        System.out.println("\n=== Deleting E001 ===");
        boolean deleted = manager.deleteEmployee("E001");
        System.out.println(deleted ? "Deleted successfully." : "Deletion failed.");

        System.out.println("\n=== Employee List After Deletion ===");
        manager.listEmployees();
    }

	}


