package inventory;

import java.util.HashMap;

public class InventoryManager {
	
	HashMap<String, Product> inventory = new HashMap<>();

    public void addProduct(Product product) {
        inventory.put(product.productId, product);
        System.out.println("Product added: " + product.productName);
    }

    public void updateProduct(String productId, int quantity, double price) {
        if (inventory.containsKey(productId)) {
            Product product = inventory.get(productId);
            product.quantity = quantity;
            product.price = price;
            System.out.println("Product updated: " + productId);
        } else {
            System.out.println("Product not found.");
        }
    }

    public void deleteProduct(String productId) {
        if (inventory.remove(productId) != null) {
            System.out.println("Product deleted: " + productId);
        } else {
            System.out.println("Product not found.");
        }
    }

    public void displayInventory() {
        for (Product p : inventory.values()) {
            p.display();
        }
    }

}
