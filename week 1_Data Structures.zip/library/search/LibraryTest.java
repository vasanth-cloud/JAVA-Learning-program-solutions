package library.search;

public class LibraryTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Book[] books = {
	            new Book("B001", "Data Structures", "Mark Allen"),
	            new Book("B002", "Algorithms", "Thomas H. Cormen"),
	            new Book("B003", "Clean Code", "Robert C. Martin"),
	            new Book("B004", "Java Fundamentals", "Herbert Schildt"),
	            new Book("B005", "Design Patterns", "Erich Gamma")
	        };

	        String searchTitle = "Clean Code";

	        
	        System.out.println("=== Linear Search ===");
	        int linearIndex = LinearSearchBooks.linearSearch(books, searchTitle);
	        if (linearIndex != -1) {
	            System.out.println("Found: " + books[linearIndex]);
	        } else {
	            System.out.println("Book not found.");
	        }

	        
	        System.out.println("\n=== Binary Search ===");
	        BinarySearchBooks.sortByTitle(books); // Must sort before binary search
	        int binaryIndex = BinarySearchBooks.binarySearch(books, searchTitle);
	        if (binaryIndex != -1) {
	            System.out.println("Found: " + books[binaryIndex]);
	        } else {
	            System.out.println("Book not found.");
	        }

	}

}
