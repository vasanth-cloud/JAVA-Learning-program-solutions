package library.search;


import java.util.Arrays;
import java.util.Comparator;

public class BinarySearchBooks {
	
	public static void sortByTitle(Book[] books) {
        Arrays.sort(books, Comparator.comparing(Book::getTitle));
    }

    public static int binarySearch(Book[] books, String title) {
        int low = 0, high = books.length - 1;

        while (low <= high) {
            int mid = (low + high) / 2;
            int result = books[mid].getTitle().compareToIgnoreCase(title);

            if (result == 0) return mid;
            if (result < 0) low = mid + 1;
            else high = mid - 1;
        }

        return -1;
    }

}
