/**
 * 
 */
/**
 * @author VASANTH A
 *
 */
module InventoryManagementSystem {
}